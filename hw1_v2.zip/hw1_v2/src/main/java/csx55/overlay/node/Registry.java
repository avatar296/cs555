package csx55.overlay.node;

import csx55.overlay.transport.TCPServerThread;
import csx55.overlay.wireformats.*;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Registry process:
 * - Accepts REGISTER and DEREGISTER over a persistent TCP connection.
 * - Keeps a map of registered <ip:port>.
 * - Provides a minimal CLI: "list-messaging-nodes".
 *
 * Entry point: java csx55.overlay.node.Registry <port>
 */
public class Registry {

    private final Map<String, InetSocketAddress> registered = new ConcurrentHashMap<>();

    public static void main(String[] args) throws Exception {
        if (args.length != 1) {
            System.err.println("Usage: java csx55.overlay.node.Registry <port>");
            return;
        }
        int port = Integer.parseInt(args[0]);
        new Registry().run(port);
    }

    private void run(int port) throws Exception {
        TCPServerThread server;
        try {
            server = new TCPServerThread(port, this::handleClient);
        } catch (java.net.BindException be) {
            System.err.println("Port " + port
                    + " is already in use. Try a different port, e.g.: ./gradlew runRegistry -Pport=6001");
            return;
        }
        Thread acceptor = new Thread(server, "registry-acceptor");
        acceptor.setDaemon(true);
        acceptor.start();

        System.out.println("Registry listening on port " + port);

        // CLI thread for commands
        Thread cli = new Thread(() -> {
            try (BufferedReader br = new BufferedReader(new InputStreamReader(System.in))) {
                String line;
                while ((line = br.readLine()) != null) {
                    line = line.trim();
                    if (line.equals("list-messaging-nodes")) {
                        listMessagingNodes();
                    }
                    // Additional commands will be added later (setup-overlay, etc.)
                }
            } catch (IOException ignored) {
            }
        }, "registry-cli");
        cli.setDaemon(true);
        cli.start();

        // Keep the main thread alive
        synchronized (this) {
            try {
                this.wait();
            } catch (InterruptedException ignored) {
            }
        }
    }

    private void listMessagingNodes() {
        registered.keySet().forEach(System.out::println);
    }

    private void handleClient(Socket s, DataInputStream in, DataOutputStream out) throws IOException {
        EventFactory factory = EventFactory.getInstance();
        try {
            while (!s.isClosed()) {
                Event ev = factory.read(in);
                if (ev instanceof Register) {
                    handleRegister((Register) ev, s, out);
                } else if (ev instanceof Deregister) {
                    handleDeregister((Deregister) ev, s, out);
                } else {
                    // ignore other messages for Step 1/2
                }
            }
        } catch (IOException ignored) {
            // socket closed or protocol error; close handler silently
        }
    }

    private void handleRegister(Register r, Socket s, DataOutputStream out) throws IOException {
        String remoteIp = s.getInetAddress().getHostAddress();
        boolean ipMatch = remoteIp.equals(r.ip());
        String key = r.ip() + ":" + r.port();

        if (!ipMatch) {
            new RegisterResponse(RegisterResponse.FAILURE, "IP mismatch").write(out);
            out.flush();
            return;
        }
        if (registered.containsKey(key)) {
            new RegisterResponse(RegisterResponse.FAILURE, "Already registered").write(out);
            out.flush();
            return;
        }

        registered.put(key, new InetSocketAddress(r.ip(), r.port()));
        String info = "Registration request successful. The number of messaging nodes currently constituting the overlay is ("
                + registered.size() + ")";
        new RegisterResponse(RegisterResponse.SUCCESS, info).write(out);
        out.flush();
    }

    private void handleDeregister(Deregister d, Socket s, DataOutputStream out) throws IOException {
        String remoteIp = s.getInetAddress().getHostAddress();
        boolean ipMatch = remoteIp.equals(d.ip());
        String key = d.ip() + ":" + d.port();

        if (!ipMatch) {
            new DeregisterResponse(DeregisterResponse.FAILURE, "IP mismatch").write(out);
            out.flush();
            return;
        }
        if (!registered.containsKey(key)) {
            new DeregisterResponse(DeregisterResponse.FAILURE, "Not registered").write(out);
            out.flush();
            return;
        }

        registered.remove(key);
        new DeregisterResponse(DeregisterResponse.SUCCESS, "Deregistration successful").write(out);
        out.flush();
    }
}
