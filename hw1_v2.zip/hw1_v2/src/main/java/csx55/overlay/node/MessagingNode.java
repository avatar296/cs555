package csx55.overlay.node;

import csx55.overlay.transport.TCPSender;
import csx55.overlay.wireformats.*;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.ServerSocket;

/**
 * MessagingNode process (minimal step):
 * - Auto-selects a listen port (ServerSocket(0)).
 * - Connects to Registry, sends REGISTER, waits for REGISTER_RESPONSE.
 * - Stays alive with a CLI; on "exit-overlay", sends DEREGISTER and prints
 * "exited overlay".
 *
 * Entry point: java csx55.overlay.node.MessagingNode <registry-host>
 * <registry-port>
 */
public class MessagingNode {

    private String selfIp;
    private int selfPort;

    public static void main(String[] args) throws Exception {
        if (args.length != 2) {
            System.err.println("Usage: java csx55.overlay.node.MessagingNode <registry-host> <registry-port>");
            return;
        }
        String host = args[0];
        int port = Integer.parseInt(args[1]);
        new MessagingNode().run(host, port);
    }

    private void run(String registryHost, int registryPort) throws Exception {
        // Reserve a port for peer connections (we'll use it later for overlay)
        ServerSocket ss = new ServerSocket(0);
        selfPort = ss.getLocalPort();

        try (TCPSender toRegistry = new TCPSender(registryHost, registryPort)) {
            // IMPORTANT: advertise the IP actually used on the registry connection
            selfIp = toRegistry.socket().getLocalAddress().getHostAddress();

            // Send REGISTER and await response
            toRegistry.send(new Register(selfIp, selfPort));
            Event resp = toRegistry.read();
            if (!(resp instanceof RegisterResponse)) {
                System.err.println("Unexpected response to REGISTER");
                return;
            }
            RegisterResponse rr = (RegisterResponse) resp;
            if (rr.status() != RegisterResponse.SUCCESS) {
                System.err.println("Registration failed: " + rr.info());
                return;
            }
            // Optionally, print rr.info() to confirm.

            // CLI thread: only deregister when the user types "exit-overlay"
            final Object blocker = new Object();
            Thread cli = new Thread(() -> {
                try (BufferedReader br = new BufferedReader(new InputStreamReader(System.in))) {
                    String line;
                    while ((line = br.readLine()) != null) {
                        line = line.trim();
                        if (line.equals("exit-overlay")) {
                            try {
                                toRegistry.send(new Deregister(selfIp, selfPort));
                                Event dr = toRegistry.read();
                                if (dr instanceof DeregisterResponse) {
                                    // Regardless of status, the required output line is:
                                    System.out.println("exited overlay");
                                } else {
                                    System.out.println("exited overlay");
                                }
                            } catch (IOException ioe) {
                                // If registry closed or network error, still print the required line
                                System.out.println("exited overlay");
                            }
                            synchronized (blocker) {
                                blocker.notifyAll();
                            }
                            return;
                        }
                        // Additional node commands (print-mst, etc.) will come later.
                    }
                    // If stdin closes (Gradle quirk), do not auto-deregister; just idle.
                } catch (IOException ignored) {
                }
            }, "node-cli");
            cli.setDaemon(true);
            cli.start();

            // Keep process alive until the CLI signals exit
            synchronized (blocker) {
                blocker.wait();
            }
        } finally {
            try {
                ss.close();
            } catch (IOException ignored) {
            }
        }
    }
}
